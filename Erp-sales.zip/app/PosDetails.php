<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PosDetails extends Model
{
    //
}
