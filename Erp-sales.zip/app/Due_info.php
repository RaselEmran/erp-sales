<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Due_info extends Model
{
    //
}
