<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AcDebitTransfer extends Model
{
    //
}
