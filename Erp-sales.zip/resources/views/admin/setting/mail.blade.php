<p>Hi, {{ $data['name'] }}</p>
<p>{{ $data['message'] }}.</p>
<p>It would be appriciative, if you gone through this feedback.</p>