<?php $__env->startSection('title','SELLS-ERP:Expense Report'); ?>
<?php $__env->startPush('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
   <div class="box">
           <div class="box-header">
              <h3 class="box-title">Expense Report</h3>

            </div>
       <div class="row">
         <div class="col-md-3" style="background: #555555;padding: 18px; margin-left: 25px;color: #fff;font-size: 22px">
          <p>Total Pay Amount</p>
<?php echo e($amt); ?>

         </div>

    <div class="col-md-3" style="background: #555555;padding: 18px; margin-left: 25px;color: #fff;font-size: 22px">
          <p>Total Paid Amount</p>
     <?php echo e($paid); ?>

         </div>
       </div>


            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                 <th>Serial</th>
                  <th>Expense To</th>
                  <th>Vouchar Name</th>
                  <th>Date</th>
                  <th>Amount</th>
                  <th>Paid</th>
                </tr>
                </thead>
                <tbody>

<?php $__currentLoopData = $expense; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $allexpense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
  <td><?php echo e($key+1); ?></td>
  <td><?php echo e($allexpense->expense_to); ?></td>
  <td><?php echo e($allexpense->vouchar_no); ?></td>
  <td><?php echo e($allexpense->date); ?></td>
  <td><?php echo e($allexpense->amount); ?></td>
  <td><?php echo e($allexpense->paid); ?></td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
                <tfoot>
                <tr>
               <th>Serial</th>
                  <th>Client Name</th>
                  <th>date</th>
                  <th>Net Total</th>
                  <th>Paid Amt</th>
                  <th>Due Amt</th>
                </tr>
                </tfoot>
              </table>
            </div>
          
   </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
   <script>

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>