<?php $__env->startSection('title','SELLS-ERP:Bank'); ?>
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="box">
<div class="row" style="max-width: 80%;margin: auto;">
<div class="well well-sm"><a href="<?php echo e(route('admin.product.backup')); ?>" class="btn btn-primary btn-block">Product Backup</a></div>

<div class="well well-lg"><a href="<?php echo e(route('admin.category.backup')); ?>" class="btn btn-primary btn-block">Category Backup</a></div>

<div class="well well-lg"><a href="<?php echo e(route('admin.supplier.backup')); ?>" class="btn btn-primary btn-block">Supplier Backup</a></div>

<div class="well well-lg"><a href="<?php echo e(route('admin.client.backup')); ?>" class="btn btn-primary btn-block">Client Backup</a></div>

<div class="well well-lg"><a href="" class="btn btn-primary btn-block">Expence Backup</a></div>

<div class="well well-lg"><a href="" class="btn btn-primary btn-block">Loan Backup</a></div>

<div class="well well-lg"><a href="" class="btn btn-primary btn-block">Bank Backup</a></div>

<div class="well well-lg"><a href="" class="btn btn-primary btn-block">Account Backup</a></div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>