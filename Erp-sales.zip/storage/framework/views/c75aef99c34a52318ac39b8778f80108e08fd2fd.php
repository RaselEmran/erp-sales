    <section class="sidebar">
      <!-- Sidebar user panel -->
<?php 
$id=Session::get('admin_id');
$prof =DB::table('admins')->where('id',$id)->first();
 ?>
      <div class="user-panel">
        <div class="pull-left image">
          <?php if(empty($prof->image)): ?>
                <img src="<?php echo e(asset('backend/dist/img/user2-160x160.jpg')); ?>" class="img-circle" alt="User Image">
                <?php else: ?>
                <img src="<?php echo e(asset($prof->image)); ?>" class="img-circle" alt="User Image" width="35px">
               
                <?php endif; ?>
        </div>
        <div class="pull-left info">
          <p> <?php echo Session::get('admin_name') ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
      <!-- /.search form -->
      <li>
        <a href="<?php echo e(url('admin/dashboard')); ?>">Dashbord</a>
      </li>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
    
        <li class="header">MAIN NAVIGATION</li>
        <li class="treeview <?php echo e(Request::is('admin/category*') ?'active':''); ?>">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Category</span>
            <span class="pull-right-container">
              <span class="label label-primary pull-right">2</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('admin/category') ?'active':''); ?>"><a href="<?php echo e(route('admin.category.index')); ?>"><i class="fa fa-circle-o"></i>All Category</a></li>
            <li class="<?php echo e(Request::is('admin/category/create') ?'active':''); ?>""><a href="<?php echo e(route('admin.category.create')); ?>"><i class="fa fa-circle-o"></i> Add Category</a></li>
          </ul>
        </li>

        <li class="treeview <?php echo e(Request::is('admin/product*') ?'active':''); ?>">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Product</span>
            <span class="pull-right-container">
              <span class="label label-danger pull-right">2</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('admin/product') ?'active':''); ?>"><a href="<?php echo e(route('admin.product.index')); ?>"><i class="fa fa-circle-o"></i>All Product</a></li>
            <li class="<?php echo e(Request::is('admin/product/create') ?'active':''); ?>""><a href="<?php echo e(route('admin.product.create')); ?>"><i class="fa fa-circle-o"></i> Add Product</a></li>
          </ul>
        </li>

        <li class="treeview <?php echo e(Request::is('admin/supplier*') ?'active':''); ?>">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Supplier</span>
            <span class="pull-right-container">
              <span class="label label-info pull-right">2</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('admin/supplier') ?'active':''); ?>"><a href="<?php echo e(route('admin.supplier.index')); ?>"><i class="fa fa-circle-o"></i>All Supplier</a></li>
            <li class="<?php echo e(Request::is('admin/supplier/create') ?'active':''); ?>""><a href="<?php echo e(route('admin.supplier.create')); ?>"><i class="fa fa-circle-o"></i> Add Supplier</a></li>
          </ul>
        </li>

           <li class="treeview <?php echo e(Request::is('admin/client*') ?'active':''); ?>">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Client</span>
            <span class="pull-right-container">
              <span class="label label-primary pull-right">2</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('admin/client') ?'active':''); ?>"><a href="<?php echo e(route('admin.client.index')); ?>"><i class="fa fa-circle-o"></i>All Client</a></li>
            <li class="<?php echo e(Request::is('admin/client/create') ?'active':''); ?>""><a href="<?php echo e(route('admin.client.create')); ?>"><i class="fa fa-circle-o"></i> Add Client</a></li>
          </ul>
        </li>

         <li class="treeview <?php echo e(Request::is('admin/pos*') ?'active':''); ?>">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Pos</span>
            <span class="pull-right-container">
              <span class="label label-primary pull-right">1</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('admin/pos/create') ?'active':''); ?>""><a href="<?php echo e(route('admin.pos.create')); ?>"><i class="fa fa-circle-o"></i> Add Pos</a></li>
          </ul>
        </li>

          <li class="treeview <?php echo e(Request::is('admin/sell*') ?'active':''); ?>">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Sell</span>
            <span class="pull-right-container">
              <span class="label label-danger pull-right">1</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('admin/sell/index') ?'active':''); ?>""><a href="<?php echo e(route('admin.sell.index')); ?>"><i class="fa fa-circle-o"></i> ALL Sell</a></li>
          </ul>
        </li>


          <li class="treeview <?php echo e(Request::is('admin/purchase*') ?'active':''); ?>">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Purchase</span>
            <span class="pull-right-container">
              <span class="label label-success pull-right">3</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('admin/purchase/index') ?'active':''); ?>""><a href="<?php echo e(route('admin.purchase.index')); ?>"><i class="fa fa-circle-o"></i> ALL Purchase</a></li>
             <li class="<?php echo e(Request::is('admin/purchase/create') ?'active':''); ?>""><a href="<?php echo e(route('admin.purchase.create')); ?>"><i class="fa fa-circle-o"></i> Add Purchase</a></li>
              <li class="<?php echo e(Request::is('admin/purchase/bysupplier') ?'active':''); ?>""><a href="<?php echo e(route('admin.purchase.bysupplier')); ?>"><i class="fa fa-circle-o"></i> By Supplier</a></li>
          </ul>
        </li>

         <li class="treeview <?php echo e(Request::is('admin/expense*') ?'active':''); ?>">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Expense</span>
            <span class="pull-right-container">
              <span class="label label-warning pull-right">2</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('admin/expense/index') ?'active':''); ?>""><a href="<?php echo e(route('admin.expense.index')); ?>"><i class="fa fa-circle-o"></i> Expense</a></li>
             <li class="<?php echo e(Request::is('admin/expense/create') ?'active':''); ?>""><a href="<?php echo e(route('admin.expense.create')); ?>"><i class="fa fa-circle-o"></i> Add Expense</a></li>
          </ul>
        </li>

          <li class="treeview <?php echo e(Request::is('admin/report*') ?'active':''); ?>">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Report</span>
            <span class="pull-right-container">
              <span class="label label-danger pull-right">5</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('admin/report/supplierreport') ?'active':''); ?>""><a href="<?php echo e(route('admim.report.supplierreport')); ?>"><i class="fa fa-circle-o"></i> Suppler Report</a></li>
             <li class="<?php echo e(Request::is('admin/report/clientreport') ?'active':''); ?>""><a href="<?php echo e(route('admin.report.clientreport')); ?>"><i class="fa fa-circle-o"></i> Client Report</a></li>
             <li class="<?php echo e(Request::is('admin/report/sellreport') ?'active':''); ?>""><a href="<?php echo e(route('admin.report.sellsreport')); ?>"><i class="fa fa-circle-o"></i> Sells Report</a></li>
              <li class="<?php echo e(Request::is('admin/report/expense') ?'active':''); ?>""><a href="<?php echo e(route('admin.report.expensereport')); ?>"><i class="fa fa-circle-o"></i> Expense Report</a></li>
               <li class="<?php echo e(Request::is('admin/report/todays') ?'active':''); ?>""><a href="<?php echo e(route('admin.report.todays')); ?>"><i class="fa fa-circle-o"></i> Todays Report</a></li>
          </ul>
        </li>

          <li class="treeview <?php echo e(Request::is('admin/loan*') ?'active':''); ?>">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Loan</span>
            <span class="pull-right-container">
              <span class="label label-warning pull-right">2</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('admin/loan/index') ?'active':''); ?>""><a href="<?php echo e(route('admin.loan.index')); ?>"><i class="fa fa-circle-o"></i> Loan</a></li>
             <li class="<?php echo e(Request::is('admin/loan/loanee') ?'active':''); ?>""><a href="<?php echo e(route('admin.loan.loanee')); ?>"><i class="fa fa-circle-o"></i> Lonee</a></li>
             <li class="<?php echo e(Request::is('admin/loan/lendar') ?'active':''); ?>""><a href="<?php echo e(route('admin.loan.lendar')); ?>"><i class="fa fa-circle-o"></i> Lendar</a></li>
          </ul>
        </li>

         <li class="treeview <?php echo e(Request::is('admin/bank*') ?'active':''); ?>">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Bank</span>
            <span class="pull-right-container">
              <span class="label label-info pull-right">4</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('admin/back/index') ?'active':''); ?>""><a href="<?php echo e(route('admin.bank.index')); ?>"><i class="fa fa-circle-o"></i> Bank</a></li>
             <li class="<?php echo e(Request::is('admin/back/transfer') ?'active':''); ?>""><a href="<?php echo e(route('admin.bank.transfer')); ?>"><i class="fa fa-circle-o"></i> Manage Transfer</a></li>

             <li class="<?php echo e(Request::is('admin/back/createtransfer') ?'active':''); ?>""><a href="<?php echo e(route('admin.bank.createtransfer')); ?>"><i class="fa fa-circle-o"></i> Account Transfer</a></li>

            <li class="<?php echo e(Request::is('admin/back/transjaction') ?'active':''); ?>""><a href="<?php echo e(route('admin.bank.transjaction')); ?>"><i class="fa fa-circle-o"></i> Transactions</a></li>
          </ul>
        </li>

        <li class="treeview <?php echo e(Request::is('admin/account*') ?'active':''); ?>">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Account</span>
            <span class="pull-right-container">
              <span class="label label-warning pull-right">3</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('admin/account/index') ?'active':''); ?>""><a href="<?php echo e(route('admin.account.index')); ?>"><i class="fa fa-circle-o"></i> Account</a></li>

              <li class="<?php echo e(Request::is('admin/account/payment') ?'active':''); ?>""><a href="<?php echo e(route('admin.account.payment')); ?>"><i class="fa fa-circle-o"></i> Payment</a></li>

               <li class="<?php echo e(Request::is('admin/account/receipt') ?'active':''); ?>""><a href="<?php echo e(route('admin.account.receipt')); ?>"><i class="fa fa-circle-o"></i> Receipt</a></li>
          </ul>
        </li>

         <li class="treeview <?php echo e(Request::is('admin/setting*') ?'active':''); ?>">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Setting</span>
            <span class="pull-right-container">
              <span class="label label-danger pull-right">1</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('admin/account/setting') ?'active':''); ?>""><a href="<?php echo e(route('admin.account.setting')); ?>"><i class="fa fa-circle-o"></i> Setting</a></li>
          </ul>
        </li>
      </ul>
    </section>