<p>Hi, <?php echo e($data['name']); ?></p>
<p><?php echo e($data['message']); ?>.</p>
<p>It would be appriciative, if you gone through this feedback.</p>