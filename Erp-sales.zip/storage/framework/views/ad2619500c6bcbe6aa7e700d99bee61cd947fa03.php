<?php $__env->startSection('title','SELLS-ERP:Update Loan'); ?>
<?php $__env->startPush('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/select2/dist/css/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Loan Update</h3>
            </div>
           <?php if(session('msg')): ?>
                  <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                    <span>
                      <b> Success - </b> <?php echo e(session('msg')); ?></span>
                  </div>
           <?php endif; ?>
                   <?php if($errors->any()): ?>
 
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                   <div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                     <span>
                      <b> Danger - </b> <?php echo e($error); ?></span>
                  </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       <?php endif; ?>
            <!-- /.box-header -->
            <div class="box-body" style="padding: 20px;width: 50%;display: block;margin: auto;">
        
              <form role="form" action="<?php echo e(route('admin.loan.update',$loan->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(@csrf_field()); ?>

                <!-- text input -->
                <div class="form-group">
                  <label>Date</label>
                  <input type="text" name="date" value="<?php echo e($loan->date); ?>" id="datepicker" class="form-control" placeholder="Enter date" required>
                </div>
                <div class="form-group">
                  <label>Lonee</label>
                <select class="form-control select2" name="loanee" style="width: 100%;">
                  <?php 
         $lonne =DB::table('loanees')->get();
                   ?>
                  <option>Select Lonee</option>
                   <?php $__currentLoopData = $lonne; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option <?php echo e($loan->loanee == $loans->id ? 'selected' : ''); ?> value="<?php echo e($loans->id); ?>"><?php echo e($loans->name); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
                <div class="form-group">
                  <label>Lender</label>
                  <?php 
          $londer =DB::table('lenders')->get();
                   ?>
                <select class="form-control select2" name="lendar" style="width: 100%;">
                  <option>Select Lender</option>
                   <?php $__currentLoopData = $londer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option <?php echo e($loan->lendar == $value->id ? 'selected' : ''); ?> value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>

                  <div class="form-group">
                  <label>Amount</label>
                  <input type="text" name="amount" value="<?php echo e($loan->amount); ?>" class="form-control" placeholder="Enter Amount" required>
                </div>

                  <div class="form-group">
                  <label>Paid</label>
                  <input type="text" name="paid" value="<?php echo e($loan->paid); ?>" class="form-control" placeholder="Enter Paid Amount" required>
                </div>
                <!-- textarea -->
                <div class="form-group">
                  <label>Note</label>
                   <textarea name="note" class="form-control"><?php echo e($loan->note); ?> </textarea>
                        
                </div>

       
       
                <button type="reset" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
         </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.all.js"></script>
 <script src="<?php echo e(asset('backend/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
  <script>
   $('#datepicker').datepicker({
      autoclose: true,
      todayHighlight: true
     // format: 'dd/mm/yyyy',
    //startDate: '-3d'
    })
    $('.select2').select2()
 </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>