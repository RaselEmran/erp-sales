<?php $__env->startSection('title','SELLS-ERP:Purchase'); ?>
<?php $__env->startPush('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
   <div class="box">
            <div class="box-header">
              <h3 class="box-title">All Purchase</h3>
             
            </div>
            <!-- /.box-header -->
              <?php if(session('msg')): ?>
                  <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                    <span>
                      <b> Success - </b> <?php echo e(session('msg')); ?></span>
                  </div>
                  <?php endif; ?>
                   <?php if($errors->any()): ?>
 
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                   <div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                     <span>
                      <b> Danger - </b> <?php echo e($error); ?></span>
                  </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       <?php endif; ?>
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                 <th>Serial</th>
                  <th>Customer Name</th>
                  <th>Date</th>
                  <th> Total</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
   <?php $__currentLoopData = $purchase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $sell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
  <td><?php echo e($key+1); ?></td>
  <td><?php echo e($sell->supp_name); ?></td>
  <td><?php echo e($sell->supp_date); ?></td>
  <td><?php echo e($sell->total); ?></td>
  <td>
    <a href="<?php echo e(route('admin.purchase.edit',$sell->id)); ?>" class="btn btn-info edit-client">Edit</a>
    <a href="<?php echo e(route('admin.purchase.invoice',$sell->id)); ?>" class="btn btn-success">Invoice</a>
        <button class="btn btn-danger" onclick="deleteTag(<?php echo $sell->id ?>)"><i class="material-icons">delete</i></button>
        <form id="delete-form-<?php echo e($sell->id); ?>" action="<?php echo e(route('admin.purchase.delete',$sell->id)); ?>" method="post" style="display: none"> <?php echo e(csrf_field()); ?></form>
  </td>
</tr>


   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                <tr>
                 <th>Serial</th>
                  <th>Customer Name</th>
                  <th>Date</th>
                  <th>Total</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
            </div>
   
          <!-- /.modal-dialog -->
   </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.all.js"></script>
    <script>
function deleteTag(id){

  const swalWithBootstrapButtons = Swal.mixin({
  confirmButtonClass: 'btn btn-success',
  cancelButtonClass: 'btn btn-danger',
  buttonsStyling: false,
})

swalWithBootstrapButtons.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  type: 'warning',
  showCancelButton: true,
  confirmButtonText: 'Yes, delete it!',
  cancelButtonText: 'No, cancel!',
  reverseButtons: true
}).then((result) => {
  if (result.value) {
       swalWithBootstrapButtons.fire(
      'Deleted!',
      'Your file has been deleted.',
      'success'

    )
   event.preventDefault();
   var a= document.getElementById('delete-form-'+id).submit();
 

  } else if (
    // Read more about handling dismissals
    result.dismiss === Swal.DismissReason.cancel
  ) {
    swalWithBootstrapButtons.fire(
      'Cancelled',
      'Your Data is safe :)',
      'error'
    )
  }
})
         }
     </script>
<script>

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>

<script>
  function preview_image(event) 
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('output_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
}
</script>

<script>
  function preview_image1(event) 
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('output_image1');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
}
</script>

<script>
  $(".edit-client").click(function(){

    var client_id =$(this).attr('client_id');


    $.ajax({

              type: 'POST',
              url: "<?php echo e(URL::to('/admin/client/edit')); ?>",
              data : {client_id:client_id},
              dateType: 'json',
              success: function(data){

                $("#id").val(data.id);
              $("#name").val(data.name);
              $("#email").val(data.email);
              $("#phone").val(data.phone);
              $("#address").text(data.address);
               $("#output_image1").attr("src",'/'+
                    data.image);
                  
               }
              
            });
  });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>