<?php $__env->startSection('title','SELLS-ERP:Product'); ?>
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
 <section class="content">

  <section class="invoice">
      <!-- title row -->
      <div id="div1">
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header">
            <i class="fa fa-globe"></i>SELLS-ERP
            <small class="pull-right">Date:<?php echo e($pos->pos_date); ?></small>
          </h2>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->
      <div class="row invoice-info">
        <div class="col-sm-6 invoice-col">
          From
          <address>
            <strong>Customer.</strong><br>
            Name : <?php echo e($customer->name); ?><br>
            Address : <?php echo e($customer->address); ?><br>
            Phone: <?php echo e($customer->phone); ?><br>
            Email: <?php echo e($customer->email); ?>

          </address>
        </div>
        <!-- /.col -->

        <!-- /.col -->
        <div class="col-sm-6 invoice-col">
          <b>Invoice #<?php echo e($pos->id); ?></b><br>
          <br>
          <b>Order Date:</b> <?php echo e($pos->pos_date); ?><br>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Table row -->
      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped">
            <thead>
            <tr>
              <th>Serial</th>
              <th>Name</th>
              <th>Quantity</th>
              <th>Price</th>
              <th>Total</th>
            </tr>
            </thead>
            <tbody>
           <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $full): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
               <td><?php echo e($key+1); ?></td>
               <td><?php echo e($full->product_name); ?></td>
               <td><?php echo e($full->qty); ?></td>
               <td><?php echo e($full->price); ?></td>
               <td><?php echo e($full->qty*$full->price); ?></td>
             </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
            </tbody>
          </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <div class="row">
        <!-- accepted payments column -->
        <div class="col-xs-6">

        </div>
        <!-- /.col -->
        <div class="col-xs-6">

          <div class="table-responsive">
            <table class="table">
              <tr>
                <th style="width:50%">Subtotal:</th>
                <td><?php echo e($pos->sub_total); ?></td>
              </tr>
              <tr>
                <th>Discount</th>
                <td><?php echo e($pos->discount); ?></td>
              </tr>
              <tr>
                <th>Net Total:</th>
                <td><?php echo e($pos->net_total); ?></td>
              </tr>
              <tr>
                <th>Paid:</th>
                <td><?php echo e($pos->paid); ?></td>
              </tr>
              <tr>
                <th>Due:</th>
                <td><?php echo e($pos->due); ?></td>
              </tr>

            </table>
          </div>
        </div>
        <!-- /.col -->
      </div>
    </div>
      <!-- /.row -->

      <!-- this row will not appear when printing -->
      <div class="row no-print">
        <div class="col-xs-12">
           <button type="button" class="btn btn-success pull-right" onclick="printContent('div1')"><i class="fa fa-print"></i> Print
          </button>
  
          <button type="button" class="btn btn-success pull-right"><i class="fa fa-credit-card"></i> Submit Payment
          </button>
          <button type="button" class="btn btn-primary pull-right" style="margin-right: 5px;">
            <i class="fa fa-download"></i> Generate PDF
          </button>
        </div>
      </div>
    </section>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
 <script>
function printContent(el){
    var restorepage = document.body.innerHTML;
    var printcontent = document.getElementById(el).innerHTML;
    document.body.innerHTML = printcontent;
    window.print();
    document.body.innerHTML = restorepage;
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>