<?php $__env->startSection('title','SELLS-ERP:By Supplier:Purchase'); ?>
<?php $__env->startPush('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
   <div class="box">
            <div class="box-header">
              <h3 class="box-title">All Purchase</h3>
            <?php 
$suppliers =DB::table('suppliers')->get();
   ?>   
            </div>
             <div class="row">
      <div class="col-md-8" style="margin-left: 10px">
      	       <div class="form-group">
                <label>Supplier</label>
                <select class="form-control select2" name="supplier_name" id="supplier_name" style="width: 100%;">
                  <option>Select Supplier</option>
        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option  value="<?php echo e($supp->id); ?>"><?php echo e($supp->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

              </div>
      </div>
             </div>
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Date</th>
                  <th> Total</th>
                  <th>Status</th>
                </tr>
                </thead>
                <tbody id="body">

                </tbody>
                <tfoot>
                <tr>
                 <th>Date</th>
                  <th> Total</th>
                  <th>Status</th>
                </tr>
                </tfoot>
              </table>
            </div>
   
          <!-- /.modal-dialog -->
   </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>

    
<script>

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>


<script>
  $("#supplier_name").change(function(){

    var supplier_name =$(this).val();


    $.ajax({

              type: 'POST',
              url: "<?php echo e(URL::to('/admin/purchase/searching')); ?>",
              data : {supplier_name:supplier_name},
              dateType: 'text',
              success: function(data){
          console.log(data);
          
                  $('#body').html(data);
                  $('#body').find(table).dataTables();
               }
              
            });
  });
</script>
<script>
    $('.select2').select2()
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>