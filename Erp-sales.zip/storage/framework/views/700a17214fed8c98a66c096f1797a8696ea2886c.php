<?php $__env->startSection('title','SELLS-ERP:Create Category'); ?>
<?php $__env->startPush('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">General Elements</h3>
            </div>
          <?php if(session('msg')): ?>
                  <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                    <span>
                      <b> Success - </b> <?php echo e(session('msg')); ?></span>
                  </div>
                  <?php endif; ?>
                   <?php if($errors->any()): ?>
 
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                   <div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                     <span>
                      <b> Danger - </b> <?php echo e($error); ?></span>
                  </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       <?php endif; ?>
            <!-- /.box-header -->
            <div class="box-body">
                <form role="form" action="<?php echo e(route('admin.product.store')); ?>" method="post"  enctype="multipart/form-data">
                <?php echo e(@csrf_field()); ?>


                <div class="row">
                  <div class="col-md-6">
                      <div class="form-group">
                      <label>Product Code</label>
                      <input type="text" name="code" class="form-control" placeholder="Enter Product Code" required>
                     </div>
                  </div>
                  <div class="col-md-6">
                       <div class="form-group">
                      <label>Product Name</label>
                      <input type="text" name="name" class="form-control" placeholder="Enter Product name" required>
                     </div>
              
                  </div>
                        <?php 
                          $cat =DB::table('categories')->get();
                         ?>
                      <div class="col-md-6">
                      <div class="form-group">
                      <label>Category</label>
                   <select class="form-control select2" name="category" style="width: 100%;" required>
                        <option>Select Category</option>
              <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($v_cat->id); ?>"><?php echo e($v_cat->name); ?></option>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                      </select>
                     </div>
                  </div>
                  <div class="col-md-6">
                       <div class="form-group">
                      <label>cost</label>
                      <input type="text" name="cost" class="form-control" placeholder="Enter Product Cost" required>
                     </div>
              
                  </div>

                     <div class="col-md-12">
                      <div class="form-group">
                      <label>Price</label>
                      <input type="text" name="price" class="form-control" placeholder="Enter Product Price" required>
                     </div>
                  </div>

                  <div class="col-md-12">
                        <div class="form-group">
                      <label>Description</label>
                       <textarea name="description" class="form-control" required> </textarea>
                            
                    </div>
                  </div>
                     <div class="col-md-6">
                       <div class="form-group">
                      <label>Image</label>
                      <input type="file" name="image" accept="image/*" onchange="preview_image(event)">
                     </div>
              
                  </div>
                  <div class="col-md-6">
                    <img id="output_image"/ style="width: 90px;height: 90px">
                  </div>
                </div>
                <!-- text input -->
             <div class="modal-footer">
                <button type="reset" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
              </div>
            </form>
          

            </div>
          
             
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
<script>
  function preview_image(event) 
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('output_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
}
  $('.select2').select2()
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>