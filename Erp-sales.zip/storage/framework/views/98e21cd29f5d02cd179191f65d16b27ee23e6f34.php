<?php $__env->startSection('title','SELLS-ERP:Create Category'); ?>
<?php $__env->startPush('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/select2/dist/css/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
 <section class="content">
 	<?php 
$customer =DB::table('clients')->get();
 	 ?>
  <div class="box box-default">
          <div class="box-body">
                <?php if(session('msg')): ?>
                  <div class="alert alert-warning">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                    <span>
                      <b> Success - </b> <?php echo e(session('msg')); ?></span>
                  </div>
                  <?php endif; ?>

           <form action="<?php echo e(route('admin.sellinfo.update',$pos->id)); ?>" method="post">
    	    <?php echo e(@csrf_field()); ?>  
    	     	    <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>Customer</label>
                <select class="form-control select2" name="customer_name" style="width: 100%;" >
                  <option>Select Customer</option>
        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cust): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option <?php echo e($custom->id == $cust->id ? 'selected' : ''); ?> value="<?php echo e($cust->id); ?>"><?php echo e($cust->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

              </div>
         

               <div class="form-group">
                <label>Date:</label>

                <div class="input-group date">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input type="text" name="pos_date" class="form-control pull-right" id="datepicker" value="<?php echo e($pos->pos_date); ?>" readonly>
                </div>
                <!-- /.input group -->
              </div>
              <!-- /.form-group -->
            </div>

            <div class="col-md-6">

             </div>
             <div class="row">
             	<div class="col-md-12">
             		<table class ="table">
             		  	<thead>
              		<th>Item Name</th>
              		<th>Item Price</th>
              		<th>Qty</th>
              		<th>Amount</th>
              	       </thead>

              	  <tbody  style="background: #097095; color: #f00;border: 1px solid black; padding: 7px">
              		    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><input type="text" name="product_name[]" value="<?php echo e($item->product_name); ?>" readonly/><input type="hidden" name="pid[]" value="<?php echo e($item->product_id); ?>" readonly"/><input type="hidden" name="code[]" value="<?php echo e($item->code); ?>" readonly/></</td>
                      <td><input type="text" name="price[]" class="price" id="price" value="<?php echo e($item->price); ?>" readonly/></td>
                      <td><input type="text" name="qty[]" class="qty" id="qty" value="<?php echo e($item->qty); ?>" readonly/><input type="hidden" name="h_qty[]" class="h_qty" id="h_qty" value="<?php echo e($item->qty); ?>"/></td>
                      '<td><span class="amt" ><?php echo e($item->qty*$item->price); ?></span></td>'
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 	</tbody>
             		</table>
             	</div>

             	<div class="col-md-6"></div>
             	<div class="col-md-6">
             		   <table class="table">
                 	<tbody>
                 		<tr>
                 			<td>
                 				Sub Total
                 			</td>
                 			<td>
                 				<input type="text" class="form-control" name="sub_total" id="sub_total" readonly required="" value="<?php echo e($pos->sub_total); ?>" readonly>
                 			</td>
                 		</tr>

                 		<tr>
                 			<td>
                 				Discount
                 			</td>
                 			<td>
                 				<input type="text" class="form-control" name="discount" id="discount" value="<?php echo e($pos->discount); ?>" readonly>
                 			</td>
                 		</tr>

                 		<tr>
                 			<td>
                 				Net Total
                 			</td>
                 			<td>
                 				<div style="background: #097095;color: #fff;height: 80px;font-size: 25px" id="net">
                 					<?php echo e($pos->net_total); ?>

                 				</div>
                 				<input type="hidden" class="form-control" name="net_total" id="net_total" value="<?php echo e($pos->net_total); ?>" readonly>
                 			</td>
                 		</tr>

                 		<tr>
                 			<td>
                 				Paid
                 			</td>
                 			<td>
                 				<input type="text" class="form-control" name="paid" id="paid" value="<?php echo e($pos->paid); ?>"  readonly>
                 			</td>
                 		</tr>

                    <tr>
                     <td><span style="font-weight: bold;">New Pay</span></td>

                     <td>
                     <input type="text" name="new_pay" id="new_pay" class="form-control form-control-sm must" required >
                    </td>
                   </tr>
                 			<tr>
                 			<td>
                 				Due
                 			</td>
                 			<td>
                 				<input type="text" class="form-control" name="due" id="due" readonly value="<?php echo e($pos->due); ?>">
                 			</td>
                 		</tr>
                 		<tr>
                 			<td>Status</td>
                 			<td>
                 <div class="form-group">

                <select class="form-control select2" name="status" style="width: 100%;">
                  <option>Select Status</option>
                  <option <?php echo e($pos->status =='Order' ? 'selected' : ''); ?> value="Order">Order</option>
                  <option <?php echo e($pos->status =='Delivered' ? 'selected' : ''); ?> value="Delivered">Delivered</option>
                </select>

              </div>
                 			</td>
                 		</tr>
                 		<tr>

                 			<td><input type="submit" name="submit" value="Submit" class="btn btn-info">
                               <input type="reset" name="reset" value="Reset" class="btn btn-danger">
                 			</td>
                 			

                 		</tr>
                 	</tbody>
                 </table>
             	</div>
             </div>
        </div>
     </form>     
</div>
</div>


</section>                  
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.all.js"></script>
 <script src="<?php echo e(asset('backend/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>

 <script>
 $('#datepicker').datepicker({
      autoclose: true,
      todayHighlight: true
    })
 //....
   $('.select2').select2()
 </script>

 <script>
  
 $("#new_pay").keyup(function(){
    var net_total =parseInt($("#net_total").val());
    var paid_amt =parseInt($("#paid").val());
    var new_pay =parseInt($("#new_pay").val());
    if (!paid_amt) {
      paid_amt=0;
    }

    var a=paid_amt+new_pay;
    var b=net_total-a;
    $("#due").val(b);
   });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>