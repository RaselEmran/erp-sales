<?php $__env->startSection('title','SELLS-ERP:Supplier Report'); ?>
<?php $__env->startPush('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
   <div class="box">
           <div class="box-header">
              <h3 class="box-title">Supplier Report</h3>
            
            </div>
<div style="background: #777777;color: #fff;font-size: 22px;text-align: center;padding-bottom: 5px">
  Supplier Name:
  <?php 
$supp =DB::table('suppliers')->where('id',$id)->first();
echo $supp->name;
   ?>
</div>
       <div class="row">
         <div class="col-md-3" style="background: #555555;padding: 18px; margin-left: 25px;color: #fff;font-size: 22px">
          <p>Total Amount</p>
           <?php 
$exp =DB::table('purchases')->where('supplier_name',$id)->sum('total');
echo $exp;
            ?>
         </div>
       </div>

            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                 <th>Serial</th>
                  <th>Purchase Date</th>
                  <th>Amount</th>
                  <th>Status</th>
                </tr>
                </thead>
                <tbody>

<?php $__currentLoopData = $single; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
  <td><?php echo e($key+1); ?></td>
  <td>
      <?php echo e($details->supp_date); ?>

  </td>


<td>
    <?php echo e($details->total); ?>

</td>


<td>
    <?php echo e($details->status); ?>

</td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
                <tfoot>
                <tr>
                <th>Serial</th>
                  <th>Supplier Name</th>
                  <th>Amount</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
            </div>
          
   </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
   <script>

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>