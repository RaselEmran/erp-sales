<?php $__env->startSection('title','SELLS-ERP:Transfer Account'); ?>
<?php $__env->startPush('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/select2/dist/css/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Account Transfer</h3>
            </div>
          <?php if(session('msg')): ?>
                  <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                    <span>
                      <b> Success - </b> <?php echo e(session('msg')); ?></span>
                  </div>
                  <?php endif; ?>
                   <?php if($errors->any()): ?>
 
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                   <div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                     <span>
                      <b> Danger - </b> <?php echo e($error); ?></span>
                  </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       <?php endif; ?>
            <!-- /.box-header -->
            <div class="box-body" style="width: 60%;margin: auto;">
              <form role="form" action="<?php echo e(route('admin.transfer.transfer-from')); ?>" method="post">
              	<?php echo e(@csrf_field()); ?>

                <!-- text input -->
                  <div class="form-group">
                <label>From</label>
                <select class="form-control select2" name="frombank" id="frombank" style="width: 100%;">
                  <option>Select an Account</option>
        <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frombank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($frombank->ac_name); ?>"><?php echo e($frombank->ac_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

              </div>

               <div class="form-group">
                <label>From</label>
                <select class="form-control select2" name="tobank" style="width: 100%;">
                  <option>Select an Account</option>
        <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tobank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($tobank->ac_name); ?>"><?php echo e($tobank->ac_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

              </div>
                <div class="form-group">
                  <label>Date</label>
                  <input type="text" name="ac_date" class="form-control pull-right" id="datepicker">
                  
                </div>

                <!-- textarea -->
                <div class="form-group">
                  <label>Description</label>
                  <textarea class="form-control" name="description" rows="3" placeholder="Enter description"></textarea>
                </div>
                 <div class="form-group" style="border-bottom: 5px">
                  <label>Amount</label>
                  <input type="text" name="ac_amount" class="form-control pull-right">
                  
                </div>
                <button type="reset" class="btn btn-danger pull-left" data-dismiss="modal">Reset</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
 <script src="<?php echo e(asset('backend/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
  <script>
   $('#datepicker').datepicker({
      autoclose: true,
      todayHighlight: true
    })
     $('.select2').select2()
 </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>