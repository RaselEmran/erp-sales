<tr id="row_<?php echo e($row); ?>">
	<td>
		<input type="text" class="form-control" name="product_name[]" value="<?php echo e($res->name); ?>" readonly >
		<input type="hidden" name="pid[]" class="pid" value="<?php echo e($res->id); ?>" readonly/>
		<input type="hidden" id="code_<?php echo e($row); ?>" data-id="<?php echo e($row); ?>" name="code[]" class="code" value="<?php echo e($res->code); ?>" readonly/>		
	</td>

	<td>
	<input type="text" name="price[]" class="price form-control" id="price" value="<?php echo e($res->price); ?>"readonly/>
	</td>

	<td>
		<input type="text" id="qty_<?php echo e($row); ?>" name="qty[]" class="qty form-control" id="qty" value="1"/>
		<input type="hidden" name="tqty[]" class="tqty" id="tqty" value="<?php echo e($res->stock); ?>"/>
	</td>

	<td>
	<span class="amt" id="amt_<?php echo e($row); ?>"><?php echo e($res->price); ?></span>
	</td>

	<td><button type="button" name="remove" class="btn btn-danger btn-sm remmove"><span class="glyphicon glyphicon-minus"></span></button></td>
</tr>