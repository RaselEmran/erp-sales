<?php $__env->startSection('title','SELLS-ERP:Transfer Account'); ?>
<?php $__env->startPush('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/select2/dist/css/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Company Profile Setting</h3>
            </div>
          <?php if(session('msg')): ?>
                  <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                    <span>
                      <b> Success - </b> <?php echo e(session('msg')); ?></span>
                  </div>
                  <?php endif; ?>
                   <?php if($errors->any()): ?>
 
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                   <div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                     <span>
                      <b> Danger - </b> <?php echo e($error); ?></span>
                  </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       <?php endif; ?>
            <!-- /.box-header -->
            <div class="box-body" style="width: 60%;margin: auto;">
              <form role="form" action="<?php echo e(route('admin.setting.company')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(@csrf_field()); ?>

                <!-- text input -->
                 <div class="form-group">
                  <label> Name</label>
                  <input type="text" name="name" class="form-control pull-right" value="<?php echo e($company->name); ?>" required>
                  
                </div>

                  <div class="form-group">
                  <label>Address</label>
                  <input type="text" name="Addess" class="form-control pull-right" value="<?php echo e($company->Addess); ?>" required >
                  
                </div>

                 <div class="form-group">
                  <label>Mobile</label>
                  <input type="text" name="mobile" class="form-control pull-right" value="<?php echo e($company->mobile); ?>" required>
                  
                </div>

                <div class="form-group">
                  <label>Email</label>
                  <input type="text" name="email" class="form-control pull-right" value="<?php echo e($company->email); ?>" required >
                  
                </div>

                <div class="form-group">
                  <label>Website</label>
                  <input type="url" name="website" class="form-control pull-right" value="<?php echo e($company->website); ?>" required>
                  
                </div>

               <div class="form-group">
                <label>logo</label>
               <input type="file" name="image">
               <img src="<?php echo e(asset($company->image)); ?>" alt="" width="70px">

              </div>
                <button type="reset" class="btn btn-danger pull-left" data-dismiss="modal">Reset</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
 <script src="<?php echo e(asset('backend/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
  <script>
   $('#datepicker').datepicker({
      autoclose: true,
      todayHighlight: true
    })
     $('.select2').select2()
 </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>