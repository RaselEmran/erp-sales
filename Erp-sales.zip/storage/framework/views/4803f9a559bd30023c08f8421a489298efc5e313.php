<?php $__env->startSection('title','SELLS-ERP:Create Category'); ?>
<?php $__env->startPush('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="box box-warning">
  <table class="table">
    <tbody>
     
      <?php for($i = 0; $i <5 ; $i++): ?>

     
    <tr>
      <td>
        <p>Product Name:<?php echo e($p_code->name); ?></p>
        <img src='https://barcode.tec-it.com/barcode.ashx?data=<?php echo e($p_code->code); ?>' alt='Barcode Generator TEC-IT'/ width="100px">
      </td>
      <td>
        <p>Product Name:<?php echo e($p_code->name); ?></p>
        <img src='https://barcode.tec-it.com/barcode.ashx?data=<?php echo e($p_code->code); ?>' alt='Barcode Generator TEC-IT'/ width="100px">
      </td>
      <td>
        <p>Product Name:<?php echo e($p_code->name); ?></p>
        <img src='https://barcode.tec-it.com/barcode.ashx?data=<?php echo e($p_code->code); ?>' alt='Barcode Generator TEC-IT'/ width="100px">
      </td>
      <td>
        <p>Product Name:<?php echo e($p_code->name); ?></p>
        <img src='https://barcode.tec-it.com/barcode.ashx?data=<?php echo e($p_code->code); ?>' alt='Barcode Generator TEC-IT'/ width="100px">
      </td>
    </tr>
         
       <?php endfor; ?> 
  
    </tbody>
  </table>

          
             
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
<script>
  function preview_image(event) 
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('output_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
}
  $('.select2').select2()
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>