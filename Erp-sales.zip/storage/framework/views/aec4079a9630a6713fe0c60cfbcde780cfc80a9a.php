<?php $__env->startSection('title','SELLS-ERP:Supplier Report'); ?>
<?php $__env->startPush('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
   <div class="box">
           <div class="box-header">
              <h3 class="box-title">Supplier Report</h3>
            
            </div>



            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                 <th>Serial</th>
                  <th>Supplier Name</th>
                  <th>Amount</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>

   <?php 
$al =DB::table('purchases')->distinct()->get(['supplier_name']);

foreach ($al as $key => $value) {
$supp =$value->supplier_name;
$ll =DB::table('suppliers')->where('id',$supp)->first();
 $bb =DB::table('purchases')->where('supplier_name', $supp)->sum('total');
?>
<tr>
  <td>
    <?php echo $key+1 ?>
  </td>
  <td>
   <?php echo $ll->name ?>
  </td>
  <td>
    <?php echo $bb; ?>
  </td>
  <td>
    <a href="<?php echo e(route('admin.report.singlesuppdetails',$supp)); ?>" class="btn btn-warning">Details</a>
  </td>
</tr>



<?php

}
    ?>

                </tbody>
                <tfoot>
                <tr>
                <th>Serial</th>
                  <th>Supplier Name</th>
                  <th>Amount</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
            </div>
          
   </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
   <script>

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>