<?php $__env->startSection('title','SELLS-ERP:Details Loan Report'); ?>
<?php $__env->startPush('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
   <div class="box">
           <div class="box-header">
              <h3 class="box-title">Loan Details Report</h3>
            
            </div>
<div style="background: #777777;color: #fff;font-size: 22px;text-align: center;padding-bottom: 5px">
  Loanee Name:
  <?php 
$supp =DB::table('loanees')->where('id',$id)->first();
echo $supp->name;
   ?>
</div>
       <div class="row">
         <div class="col-md-3" style="background: #555555;padding: 18px; margin-left: 25px;color: #fff;font-size: 22px">
          <p>Total Pay Amount</p>
           <?php 
$exp =DB::table('loans')->where('loanee',$id)->sum('amount');
echo $exp;
            ?>
         </div>

    <div class="col-md-3" style="background: #555555;padding: 18px; margin-left: 25px;color: #fff;font-size: 22px">
          <p>Total Paid Amount</p>
           <?php 
$exp =DB::table('loans')->where('loanee',$id)->sum('paid');
echo $exp;
            ?>
         </div>
       </div>

            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                 <th>Serial</th>
                  <th>date</th>
                  <th>Pay Amt</th>
                  <th>Paid Amt</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>

<?php $__currentLoopData = $single; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
  <td><?php echo e($key+1); ?></td>
  <td>
      <?php echo e($details->date); ?>

  </td>


<td>
    <?php echo e($details->amount); ?>

</td>


<td>
    <?php echo e($details->paid); ?>

</td>
<td>
	<a href="<?php echo e(route('admin.loan.edit',$details->id)); ?>" class="btn btn-info">Edit</a>
</td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
                <tfoot>
                <tr>
                <th>Serial</th>
                  <th>date</th>
                  <th>Pay Amt</th>
                  <th>Paid Amt</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
            </div>
          
   </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
   <script>

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>