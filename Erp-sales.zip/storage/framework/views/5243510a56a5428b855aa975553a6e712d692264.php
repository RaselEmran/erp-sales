<?php $__env->startSection('title','SELLS-ERP:Bank'); ?>
<?php $__env->startPush('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
        <?php if(session('msg')): ?>
                  <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                    <span>
                      <b> Success - </b> <?php echo e(session('msg')); ?></span>
                  </div>
         <?php endif; ?>

         <?php if(session('emsg')): ?>
                  <div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                    <span>
                      <b> Success - </b> <?php echo e(session('emsg')); ?></span>
                  </div>
         <?php endif; ?>
  <div class="box-body">
<form action=""  name="frmUser" method="post">
	<?php echo e(@csrf_field()); ?>

	<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example1">
		<div class="alert alert-success">
			<h2 style="text-align:center; font-family:cursive;">Backup Or Destroy Client</h2>
		</div>
		<thead>
<button type="button" class="btn btn-info" onClick="setUpdateAction();"><i class="fa fa-fw fa-undo" style="margin-right: 5px"></i></button><button type="button" class="btn btn-danger" onClick="setDeleteAction();"><i class="fa fa-fw fa-trash"></i></button>
			<tr>
				  <th style="text-align:center; font-family:cursive; font-size:18px; color:blue;">Serial</th>
                  <th style="text-align:center; font-family:cursive; font-size:18px; color:blue;">Name</th>
                  <th style="text-align:center; font-family:cursive; font-size:18px; color:blue;">Email</th>
                  <th style="text-align:center; font-family:cursive; font-size:18px; color:blue;">Phone</th>
                  <th style="text-align:center; font-family:cursive; font-size:18px; color:blue;">Address</th>
				  <th style="text-align:center; font-family:cursive; font-size:18px; color:blue;">Action</th>
			</tr>
		</thead>
		<tbody>
       <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
			<tr>
				<td style="text-align:center; font-family:cursive; font-size:18px;"><?php echo e($key+1); ?></td>
				<td style="text-align:center; font-family:cursive; font-size:18px;"><?php echo e($element->name); ?></td>
				<td style="text-align:center; font-family:cursive; font-size:18px;"><?php echo e($element->email); ?></td>
        <td style="text-align:center; font-family:cursive; font-size:18px;"><?php echo e($element->phone); ?></td>
        <td style="text-align:center; font-family:cursive; font-size:18px;"><?php echo e($element->address); ?></td>
				<td style="text-align:center; font-family:cursive; font-size:18px;">
					<input name="selector[]" type="checkbox" value="<?php echo e($element->id); ?>">
				</td>
			</tr>	
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			 
		</tbody>
	</table>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.all.js"></script>
<script>
  $(function () {
    $('#example1').DataTable({
    	'lengthChange': false,
    	'info'        : false,
    })
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })

function setUpdateAction() {
document.frmUser.action = "<?php echo e(route('admin.backup.resetsupplier')); ?>";
document.frmUser.submit();
}
function setDeleteAction() {

Swal.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  type: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {

  if (result.value) {
  	  event.preventDefault();
  	document.frmUser.action = "<?php echo e(route('admin.backup.destroysupplier')); ?>";
    document.frmUser.submit();
    Swal.fire(
      'Deleted!',
      'Your file has been deleted.',
      'success'
    )
  }
})



}
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>