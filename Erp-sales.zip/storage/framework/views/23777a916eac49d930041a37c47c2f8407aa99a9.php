<?php $__env->startSection('title','SELLS-ERP:Payment system'); ?>
<?php $__env->startPush('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/select2/dist/css/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="box box-warning">
            <div class="box-header with-border">
<h3> Update Receipt</h3>
            </div>
          <?php if(session('msg')): ?>
                  <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                    <span>
                      <b> Success - </b> <?php echo e(session('msg')); ?></span>
                  </div>
                  <?php endif; ?>
                   <?php if($errors->any()): ?>
 
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                   <div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                     <span>
                      <b> Danger - </b> <?php echo e($error); ?></span>
                  </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       <?php endif; ?>
            <!-- /.box-header -->
            <div class="box-body" style="width: 60%;margin: auto;" id="form_body">
              <form role="form" action="<?php echo e(route('admin.account.upreceipt',$payment->id)); ?>" method="post">
              	<?php echo e(@csrf_field()); ?>

                <!-- text input -->
                <div class="row">
                	<div class="col-md-6">
                     	<div class="form-group">
	                  	 <label>Date</label>
	                  	 <input type="text" name="ac_date" class="form-control pull-right" id="datepicker" value="<?php echo e($payment->ac_date); ?>">
	                  
                	   </div>
                	</div>
                	<div class="col-md-6">
                     <div class="form-group">
                     <label>Description</label>
                      <textarea class="form-control" name="description" rows="3" placeholder="Enter description">
                        <?php echo e($payment->description); ?>

                      </textarea>
                    </div>
                	</div>
                	<div class="col-md-6">
                       <div class="form-group">
		                  <label>Root Account*</label>
		               <input type="text" name="root_acc" readonly class="form-control pull-right" value="<?php echo e($payment->root_acc); ?>">
                 
                       </div>
                	</div>
                	<div class="col-md-6">
                    <?php if($payment->root_acc =='customer'): ?>
                      <div class="form-group" style="border-bottom: 5px;" id="customer">
                       <label>Customer Name</label>
                       <input type="text" name="customer" class="form-control pull-right" value="<?php echo e($payment->customer); ?>">
                  
                     </div>
                      <?php elseif($payment->root_acc =='supplier'): ?>
                         <div class="form-group"  id="supplier">
                           <label>Supplier</label>
                           <?php 
                          $supplier =DB::table('suppliers')->get();
                            ?>
                           <select class="form-control select2" name="supplier" style="width: 100%;">

                            <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e($payment->supplier == $supp->name ? 'selected' : ''); ?> value="<?php echo e($supp->name); ?>"><?php echo e($supp->name); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>

                         </div>
                         <?php elseif($payment->root_acc =='office'): ?>

                           <div class="form-group"  id="office">
                           <label>Office</label>
                           <select class="form-control select2" name="office"  style="width: 100%;">
                            <option <?php echo e($payment->office == 'office' ? 'selected' : ''); ?>  value="office">Office</option>
		                    <option  <?php echo e($payment->office == 'office_expense' ? 'selected' : ''); ?>  value="office_expense">Office Expense</option>
		                    <option <?php echo e($payment->office == 'convince_bill' ? 'selected' : ''); ?>  value="convince_bill">Convince Bill</option>
		                    <option <?php echo e($payment->office == 'stationary' ? 'selected' : ''); ?>  value="stationary">Stationary</option>

                          </select>

                         </div>
                         <?php elseif($payment->root_acc =='loan'): ?>
                           <div class="form-group"  id="loanname">
                           <label>Loan Name</label>
                            <input type="text" name="loan_name" class="form-control pull-right" value="<?php echo e($payment->loan_name); ?>">

                         </div>
                         <?php endif; ?>
                	</div>
                </div>
          
              <div class="row">
              	<div class="col-md-6">
              	  <div class="form-group">
                   <label>Payment Mode</label>
                    <input type="text" name="mode" readonly class="form-control pull-right" value="<?php echo e($payment->mode); ?>">

              </div>
              	</div>
              	<div class="col-md-6"></div>
              	<div class="col-md-6">
              	 <div class="form-group">
                    <label>Payment Amount</label>
                    <input type="text" name="amount" class="form-control" value="<?php echo e($payment->amount); ?>">

                 </div>
              	</div>
              </div>
          <?php if($payment->mode=='check'): ?>
            <div class="row" id="check" >
            	<div class="col-md-6">
            		 <div class="form-group">
                    <label>Cheque/Pay Order No *</label>
                    <input type="text" name="check_num" class="form-control" value="<?php echo e($payment->check_num); ?>">

                 </div>
            	</div>
            	<div class="col-m-6"></div>

            		<div class="col-md-6">
            		 <div class="form-group">
                    <label>Date *</label>
                    <input type="text" name="check_date" class="form-control" id="datepicker1" value="<?php echo e($payment->check_date); ?>">

                 </div>
                 <div class="col-md-6">
                 	
                 </div>
            	</div>
            		<div class="col-md-6">
            		 <div class="form-group">
                    <label>Bank Name *</label>
                    <?php 
$bank=DB::table('banks')->get();
                     ?>
                      <select class="form-control select2" name="bank_name" id="mode" style="width: 100%;">
                      <option value="">Select an Mode</option>
                      <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allbank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option  <?php echo e($payment->bank_name == $allbank->b_name ? 'selected' : ''); ?>  value="<?php echo e($allbank->b_name); ?>"><?php echo e($allbank->b_name); ?></option>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
                   </select>

                 </div>
            	</div>
            </div>
            <?php endif; ?>


                <button type="button" id="close" class="btn btn-danger pull-left">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </form>
        </div>
      </div>
   <?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
 <script src="<?php echo e(asset('backend/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
  <script>
      $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
   $('#datepicker').datepicker({
      autoclose: true,
      todayHighlight: true
    })
    $('#datepicker1').datepicker({
      autoclose: true,
      todayHighlight: true
    })
     $('.select2').select2()
 </script>
  

<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>