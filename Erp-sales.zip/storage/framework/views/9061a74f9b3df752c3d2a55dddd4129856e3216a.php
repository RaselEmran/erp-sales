<?php $__env->startSection('title','SELLS-ERP:Sell'); ?>
<?php $__env->startPush('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('backend/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
   <div class="box">
            <div class="box-header">
              <h3 class="box-title">Due Sell Information</h3>
  
            </div>
            <!-- /.box-header -->
               <?php if(session('sms')): ?>
                  <div class="alert alert-warning">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                    <span>
                      <b> Success - </b> <?php echo e(session('sms')); ?></span>
                  </div>
                  <?php endif; ?>
              <?php if(session('msg')): ?>
                  <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                    <span>
                      <b> Success - </b> <?php echo e(session('msg')); ?></span>
                  </div>
                  <?php endif; ?>
                   <?php if($errors->any()): ?>
 
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                   <div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                     <span>
                      <b> Danger - </b> <?php echo e($error); ?></span>
                  </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       <?php endif; ?>
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                 <th>Serial</th>
                  <th>Customer Name</th>
                  <th>Date</th>
                  <th>Sub Total</th>
                  <th>Discount</th>
                  <th>Net Total</th>
                  <th>Due</th>
                  <th>Paid</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
   <?php $__currentLoopData = $pos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $sell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
  <td><?php echo e($key+1); ?></td>
  <td><?php echo e($sell->cus_name); ?></td>
  <td><?php echo e($sell->pos_date); ?></td>
  <td><?php echo e($sell->sub_total); ?></td>
  <td><?php echo e($sell->discount); ?></td>
  <td><?php echo e($sell->net_total); ?></td>
  <td><?php echo e($sell->due); ?></td>

  <td><?php echo e($sell->paid); ?></td>


  <td>
    <a href="<?php echo e(route('admin.sellinfo.editdue',$sell->id)); ?>" class="btn btn-info edit-client">Pay</a>
    <a href="<?php echo e(route('admin.sellinfo.invoice',$sell->id)); ?>" class="btn btn-success">Invoice</a>
     
  </td>
</tr>


   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                <tr>
                 <th>Serial</th>
                  <th>Customer Name</th>
                  <th>Date</th>
                  <th>Sub Total</th>
                  <th>Discount</th>
                  <th>Net Total</th>
                  <th>Due</th>
                  <th>Paid</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
            </div>
   
          <!-- /.modal-dialog -->
   </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.all.js"></script>
<script>

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>